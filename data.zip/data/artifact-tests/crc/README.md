The CRCs for a specific file are stored in a text file with the same name (excluding the original extension).

The CRCs are calculated for data chunks of `32768 bytes` (individual CRCs) and are newline delimited.

The CRCs were calculated using https://simplycalc.com/crc32-file.php